/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleshipgame;

import userInterface.BattleshipUI;
import userInterface.GameOptionDialog;
import userInterface.Player;
import userInterface.PlayerOptionDialog;

/**
 *
 * @author alyssa
 */
public class BattleshipGame 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        BattleshipUI ui = new BattleshipUI();
        
    }
    
}
